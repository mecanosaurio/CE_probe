"""
mixed_01.py
------------------
APP_NAME: 						MxNets
Consumer Key (API Key) 			7TYZXZGpSZYxUhuUKBttEULGi
Consumer Secret (API Secret) 	x1g5SQXL7WPv2kHERcYzPS7oLHEcXVD1bzeTedsIFBvkQ2ArBg
Access Token 					2694758526-t4kM9Ca6L4Bvf9Q9y7ORRwiCFVSxbcYYwOYDPJR
Access Token Secret 			qgb2QFHYFFzscFEukqT7DFffqlQpOHXyKr3MzKm63Q6vZ 
"""


# -*- coding: utf-8 -*-
import os
from time import sleep
from microbot import MicroBot
tbot_0 = MicroBot()


# load data
dirname = "."
book = os.path.join(dirname, 'season1.txt')
tbot_0.read(book)
my_first_text = tbot_0.generate_text(25, seedword=['dos', 'uno'])
print("[b0]:" + my_first_text)

# keys
cons_key = '7TYZXZGpSZYxUhuUKBttEULGi'
cons_secret = 'x1g5SQXL7WPv2kHERcYzPS7oLHEcXVD1bzeTedsIFBvkQ2ArBg'
access_token = '2694758526-t4kM9Ca6L4Bvf9Q9y7ORRwiCFVSxbcYYwOYDPJR'
access_token_secret = 'qgb2QFHYFFzscFEukqT7DFffqlQpOHXyKr3MzKm63Q6vZ'

user = "_mixedreality_"
tbot_0.twitter_login(cons_key, cons_secret, access_token, access_token_secret, user)
# tbot._credentials

# monitor
# #Feminicidios OR #MachismoMata OR #NosQueremosVivas OR #NiUnaMenos
targetstr_0 = '#niunamenos'
tbot_0.twitter_monitor_start(targetstr_0)
#tbot.twitter_monitor_stop()

while(1):
	new_text = tbot_0.generate_text(25, seedword=['el', 'no'])
	print ("\t\t[._.] +0: "+ new_text) 
	sleep(360)

"""
#autotweet
keywords = ['corre', 'trasero', 'tiempo', 'nave']
prefix = None
suffix = None #'#RandM'
maxconvdepth = 10 #None
tbot.twitter_tweeting_start(days=0, hours=0, \
	minutes=1, jitter=1, keywords=None, prefix=None, suffix=None)
#tbot.twitter_tweeting_stop()

# autoreply
targetstring = 'Rick Morty'
keywords = ['corre', 'trasero', 'tiempo', 'nave']
prefix = None
suffix = None #'#RandM'
maxconvdepth = 10 #None
tbot.twitter_autoreply_start(targetstring, keywords=keywords, prefix=prefix, \
							suffix=suffix, maxconvdepth=maxconvdepth)
#tbot.twitter_autoreply_stop()
"""